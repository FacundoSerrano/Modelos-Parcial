#ifndef USUARIO_H_INCLUDED
#define USUARIO_H_INCLUDED

typedef struct{
    int idUsuario;
    char nombre[50];
}eUsuario;

void CrearListadoDeUsuarios(eUsuario MisUsuarios[], int cantidad);


#endif // USUARIO_H_INCLUDED
