#include "usuarioSerie.h"
#include "usuario.h"
#include "serie.h"

void CrearListadoUsuariosYSeries(eUsuarioSerie misRelaciones[])
{
}
