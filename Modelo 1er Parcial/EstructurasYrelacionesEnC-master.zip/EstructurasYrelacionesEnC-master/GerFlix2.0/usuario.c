#include "usuario.h"

void CrearListadoDeTresUsuarios(eUsuario MisUsuarios[])
{

}
